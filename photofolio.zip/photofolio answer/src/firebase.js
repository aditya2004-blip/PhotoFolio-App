// Import the functions you need from the SDKs you want to use
import { initializeApp } from "firebase/app";
import { getFirestore } from "firebase/firestore";
import { getStorage } from "firebase/storage"; // Import Firebase Storage

// Your web app's Firebase configuration
const firebaseConfig = {
  apiKey: "AIzaSyA_pk1bisKPxcPhAUQFPF-prja3cEN67QI",
  authDomain: "photofolio-app-18e05.firebaseapp.com",
  projectId: "photofolio-app-18e05",
  storageBucket: "photofolio-app-18e05.appspot.com",
  messagingSenderId: "682810354533",
  appId: "1:682810354533:web:1bf6fadab3875d5dcbcf8c",
};

// Initialize Firebase
const app = initializeApp(firebaseConfig);
const db = getFirestore(app);
const storage = getStorage(app); // Initialize Firebase Storage

export { db, storage }; // Export both Firestore and Storage
